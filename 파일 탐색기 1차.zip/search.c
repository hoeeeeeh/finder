#include "myheader.h"

void search_main(){
        DIR* dir_info;
        struct dirent* dir_entry;

        char input[256];
        printf("디렉토리/파일 이름의 일부분 또는 전체 입력 : ");
        scanf("%s",input);
        dir_info = opendir(finder("찾고 싶은 위치를 선택해주세요"));
        if(NULL != dir_info){
                while((dir_entry = readdir(dir_info)) != NULL)
                {
                        char* ptr = strstr(dir_entry->d_name, input);

                        if(ptr != NULL){
                        printf("%s\n",dir_entry->d_name);
                        }
                }
                closedir(dir_info);
        }
}